"""
BatchBodyExport - Fusion add-in
Select many bodies (or tick "all visible bodies") and export each one as its own
STEP / STL / 3MF file into a folder you choose.
"""
import adsk.core
import adsk.fusion
import os
import re
import traceback

CMD_ID = 'batchBodyExportCmd'
CMD_NAME = 'Batch Export Bodies'
CMD_DESC = 'Export each selected body as its own STEP, STL or 3MF file'
PANEL_ID = 'SolidScriptsAddinsPanel'  # Utilities tab > Add-Ins panel

app = None
ui = None
handlers = []  # keep references alive so Python doesn't garbage-collect them


# --------------------------------------------------------------------------
# helpers
# --------------------------------------------------------------------------
def safe_name(name):
    name = re.sub(r'[\\/:*?"<>|]+', '_', name).strip().strip('.')
    return name or 'body'


def unique_path(folder, base, ext, used):
    candidate = base
    n = 2
    while candidate.lower() in used:
        candidate = '{}_{}'.format(base, n)
        n += 1
    used.add(candidate.lower())
    return os.path.join(folder, candidate + ext)


def body_label(body):
    """Component name + body name, so 'Body1' in different parts doesn't collide."""
    occ = body.assemblyContext
    if occ is not None:
        return safe_name('{}_{}'.format(occ.component.name, body.name))
    return safe_name(body.name)


def all_visible_bodies(design):
    bodies = []
    root = design.rootComponent
    for b in root.bRepBodies:
        if b.isVisible:
            bodies.append(b)
    for occ in root.allOccurrences:
        for b in occ.bRepBodies:  # proxies, so world position is preserved
            if b.isVisible:
                bodies.append(b)
    return bodies


# --------------------------------------------------------------------------
# the actual export
# --------------------------------------------------------------------------
def export_bodies(design, bodies, fmt, folder):
    total = len(bodies)
    used = set()
    failed = []
    done = 0

    progress = ui.createProgressDialog()
    progress.isBackgroundTranslucent = False
    progress.show('Batch Export', 'Exporting body %v of %m', 0, total, 1)

    scratch_doc = None
    orig_doc = app.activeDocument
    try:
        if fmt == 'STEP':
            # Fusion's STEP exporter only accepts components, not single bodies.
            # Workaround: copy each body into a scratch direct-design document,
            # export that document's root component, then delete the copy.
            scratch_doc = app.documents.add(adsk.core.DocumentTypes.FusionDesignDocumentType)
            scratch = adsk.fusion.Design.cast(
                scratch_doc.products.itemByProductType('DesignProductType'))
            scratch.designType = adsk.fusion.DesignTypes.DirectDesignType
            tbm = adsk.fusion.TemporaryBRepManager.get()

        for i, body in enumerate(bodies):
            if progress.wasCancelled:
                break
            progress.progressValue = i + 1
            adsk.doEvents()
            label = body_label(body)
            try:
                if fmt == 'STEP':
                    path = unique_path(folder, label, '.step', used)
                    tmp = tbm.copy(body)
                    new_body = scratch.rootComponent.bRepBodies.add(tmp)
                    opts = scratch.exportManager.createSTEPExportOptions(
                        path, scratch.rootComponent)
                    ok = scratch.exportManager.execute(opts)
                    new_body.deleteMe()
                elif fmt == 'STL':
                    path = unique_path(folder, label, '.stl', used)
                    opts = design.exportManager.createSTLExportOptions(body, path)
                    opts.meshRefinement = adsk.fusion.MeshRefinementSettings.MeshRefinementMedium
                    opts.sendToPrintUtility = False
                    ok = design.exportManager.execute(opts)
                else:  # 3MF
                    path = unique_path(folder, label, '.3mf', used)
                    opts = design.exportManager.createC3MFExportOptions(body, path)
                    ok = design.exportManager.execute(opts)
                if ok:
                    done += 1
                else:
                    failed.append(label)
            except Exception:
                failed.append(label)
    finally:
        progress.hide()
        if scratch_doc is not None:
            scratch_doc.close(False)  # discard scratch doc without saving
            try:
                orig_doc.activate()
            except Exception:
                pass

    msg = 'Exported {} of {} bodies to:\n{}'.format(done, total, folder)
    if failed:
        msg += '\n\nFailed ({}):\n{}'.format(len(failed), '\n'.join(failed[:20]))
    ui.messageBox(msg, CMD_NAME)


# --------------------------------------------------------------------------
# command UI
# --------------------------------------------------------------------------
class ValidateHandler(adsk.core.ValidateInputsEventHandler):
    def notify(self, args):
        try:
            inputs = args.inputs
            sel = inputs.itemById('bodies')
            all_box = inputs.itemById('allVisible')
            args.areInputsValid = all_box.value or sel.selectionCount > 0
        except Exception:
            pass


class ExecuteHandler(adsk.core.CommandEventHandler):
    def notify(self, args):
        try:
            inputs = args.command.commandInputs
            sel = inputs.itemById('bodies')
            all_box = inputs.itemById('allVisible')
            fmt = inputs.itemById('format').selectedItem.name

            design = adsk.fusion.Design.cast(app.activeProduct)
            if design is None:
                ui.messageBox('Switch to the Design workspace first.', CMD_NAME)
                return

            if all_box.value:
                bodies = all_visible_bodies(design)
            else:
                bodies = [sel.selection(i).entity for i in range(sel.selectionCount)]
            bodies = [adsk.fusion.BRepBody.cast(b) for b in bodies]
            bodies = [b for b in bodies if b is not None]

            if not bodies:
                ui.messageBox('No bodies to export.', CMD_NAME)
                return

            dlg = ui.createFolderDialog()
            dlg.title = 'Choose export folder'
            if dlg.showDialog() != adsk.core.DialogResults.DialogOK:
                return

            export_bodies(design, bodies, fmt, dlg.folder)
        except Exception:
            ui.messageBox('Failed:\n{}'.format(traceback.format_exc()))


class CreatedHandler(adsk.core.CommandCreatedEventHandler):
    def notify(self, args):
        try:
            cmd = args.command
            inputs = cmd.commandInputs

            sel = inputs.addSelectionInput(
                'bodies', 'Bodies', 'Select bodies (click, or drag a window)')
            sel.addSelectionFilter('SolidBodies')
            sel.setSelectionLimits(0, 0)  # 0 max = unlimited

            inputs.addBoolValueInput(
                'allVisible', 'Export ALL visible bodies (ignores selection)', True, '', False)

            fmt = inputs.addDropDownCommandInput(
                'format', 'Format', adsk.core.DropDownStyles.TextListDropDownStyle)
            fmt.listItems.add('STEP', True)
            fmt.listItems.add('STL', False)
            fmt.listItems.add('3MF', False)

            on_validate = ValidateHandler()
            cmd.validateInputs.add(on_validate)
            handlers.append(on_validate)

            on_execute = ExecuteHandler()
            cmd.execute.add(on_execute)
            handlers.append(on_execute)
        except Exception:
            ui.messageBox('Failed:\n{}'.format(traceback.format_exc()))


# --------------------------------------------------------------------------
# add-in entry points
# --------------------------------------------------------------------------
def run(context):
    global app, ui
    try:
        app = adsk.core.Application.get()
        ui = app.userInterface

        cmd_def = ui.commandDefinitions.itemById(CMD_ID)
        if cmd_def:
            cmd_def.deleteMe()
        cmd_def = ui.commandDefinitions.addButtonDefinition(CMD_ID, CMD_NAME, CMD_DESC)

        on_created = CreatedHandler()
        cmd_def.commandCreated.add(on_created)
        handlers.append(on_created)

        panel = ui.allToolbarPanels.itemById(PANEL_ID)
        if panel.controls.itemById(CMD_ID) is None:
            ctrl = panel.controls.addCommand(cmd_def)
            ctrl.isPromoted = True
    except Exception:
        if ui:
            ui.messageBox('Failed:\n{}'.format(traceback.format_exc()))


def stop(context):
    try:
        panel = ui.allToolbarPanels.itemById(PANEL_ID)
        ctrl = panel.controls.itemById(CMD_ID)
        if ctrl:
            ctrl.deleteMe()
        cmd_def = ui.commandDefinitions.itemById(CMD_ID)
        if cmd_def:
            cmd_def.deleteMe()
    except Exception:
        if ui:
            ui.messageBox('Failed:\n{}'.format(traceback.format_exc()))
